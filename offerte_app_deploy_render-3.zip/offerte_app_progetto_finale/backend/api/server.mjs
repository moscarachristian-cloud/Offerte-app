import express from "express";
import cors from "cors";
import fs from "node:fs/promises";
import path from "node:path";
import {fileURLToPath} from "node:url";
const app=express(); app.use(cors()); app.use(express.json());
const root=path.dirname(fileURLToPath(import.meta.url));
const file=path.join(root,"..","data","offers.json");
async function data(){try{return JSON.parse(await fs.readFile(file,"utf8"))}catch{return {updated_at:null,offers:[]}}}
app.get("/api/health",(_,r)=>r.json({ok:true,service:"offerte-app-api"}));
app.get("/api/offers",async(req,r)=>{
 const d=await data(), q=String(req.query.q||"").toLowerCase().trim(), store=String(req.query.store||"").toLowerCase().trim();
 let a=d.offers||[];
 if(q)a=a.filter(x=>[x.name,x.brand,x.format,x.ean].filter(Boolean).join(" ").toLowerCase().includes(q));
 if(store)a=a.filter(x=>x.store.toLowerCase()===store);
 r.json({updated_at:d.updated_at,count:a.length,offers:a});
});
app.get("/api/stores",async(_,r)=>r.json([...new Set((await data()).offers.map(x=>x.store))].sort()));
app.post("/api/basket/compare",async(req,r)=>{
 const d=await data(), items=Array.isArray(req.body.items)?req.body.items:[], totals={};
 for(const item of items){
  const q=String(item).toLowerCase();
  for(const x of d.offers) if([x.name,x.brand,x.format,x.ean].filter(Boolean).join(" ").toLowerCase().includes(q) && typeof x.price==="number")
   totals[x.store]=(totals[x.store]||0)+x.price;
 }
 r.json({updated_at:d.updated_at,totals});
});
const frontendDir=path.join(root,"..","..","frontend");
app.use(express.static(frontendDir));
app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).json({error:"Not found"});
  res.sendFile(path.join(frontendDir,"index.html"));
});
const PORT=Number(process.env.PORT||8787);
app.listen(PORT,"0.0.0.0",()=>console.log(`Offerte App listening on ${PORT}`));
