import fs from "node:fs/promises";
const s=JSON.parse(await fs.readFile(new URL("../data/sources.json",import.meta.url),"utf8"));
const out=[];
for(const x of s){try{const r=await fetch(x.url,{redirect:"follow",headers:{"user-agent":"OfferteApp/1.0"}});out.push({store:x.store,status:r.status,ok:r.ok,checked_at:new Date().toISOString()})}catch(e){out.push({store:x.store,status:0,ok:false,error:String(e),checked_at:new Date().toISOString()})}}
await fs.writeFile(new URL("../data/source-health.json",import.meta.url),JSON.stringify({checked_at:new Date().toISOString(),sources:out},null,2));
console.log(JSON.stringify(out,null,2));
