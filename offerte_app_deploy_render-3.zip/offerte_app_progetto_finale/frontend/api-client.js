const API_BASE = window.OFFERTE_API_BASE || "http://localhost:8787";
export async function searchOffers(q,store=""){
 const u=new URL(API_BASE+"/api/offers"); u.searchParams.set("q",q); if(store)u.searchParams.set("store",store);
 return (await fetch(u)).json();
}
export async function compareBasket(items){
 const r=await fetch(API_BASE+"/api/basket/compare",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({items})});
 return r.json();
}
