# Offerte App — build 3
Prototipo PWA con catalogo strutturato, lista carrello persistente e confronto.
Le fonti ufficiali devono essere interrogate/aggiornate dal backend prima di usare i prezzi come dati commerciali.
