# Pubblicazione su Render

## 1. GitHub
Carica l'intera cartella del progetto in un nuovo repository GitHub.

## 2. Render
Nel Dashboard Render scegli **New → Blueprint**, collega il repository e seleziona il file `render.yaml` nella radice.

Render userà:
- Root Directory: `backend`
- Build: `npm install`
- Start: `npm start`
- Health check: `/api/health`

Il server pubblica anche la cartella `frontend`, quindi frontend e API funzionano dallo stesso indirizzo.

## 3. Importante
Il progetto è pronto per la pubblicazione tecnica, ma `backend/data/offers.json` contiene ancora il database offerte verificato vuoto. Non vengono inventati prezzi. L'integrazione automatica con i dati commerciali dei supermercati è un passaggio separato.
