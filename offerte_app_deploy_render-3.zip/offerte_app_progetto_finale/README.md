# Offerte App — progetto finale

## Cosa contiene
- frontend PWA installabile
- backend Node/Express
- API ricerca offerte
- API confronto carrello
- struttura dati con EAN, formato, prezzo, sconto, periodo, carta e fonte
- controllo raggiungibilità delle fonti
- Dockerfile per pubblicare il backend

## Avvio backend
1. Installare Node.js 22+
2. entrare in `backend`
3. `npm install`
4. `npm start`

API: `http://localhost:8787/api/health`

## Collegare il frontend
Impostare nel browser:
`localStorage.setItem('offerte_api_base','https://TUO-SERVER')`
e ricaricare l'app.

## Dati reali
Il file `backend/data/offers.json` è volutamente vuoto: non vengono inventati prezzi.
Per popolarlo servono API/feed/licenze o altre fonti autorizzate. Le offerte possono dipendere
da punto vendita e carta fedeltà, quindi questi campi fanno parte del modello dati.
